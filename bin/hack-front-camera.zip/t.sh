
clear='\033[0m'
Black='\033[0;30m'
Red='\033[0;31m'
Green='\033[0;32m'
Yellow='\033[0;33m'
Blue='\033[0;34m'
Purple='\033[0;35m'
Cyan='\033[0;36m'
White='\033[0;37m'

arch=$(uname -m)
#supported
#aarch64
#elarm
#elx86_64
#x86_64
#elarm64
mkdir $HOME/.linksnow > /dev/null 2>&1

if [ "$arch" == 'aarch64' ];
then 
echo -e "${Yellow}[${White}+${Yellow}] Dwnloading ngrok...${clear}"
curl -L -o $HOME/.linksnow/ngrok.tgz https://github.com/KasRoudra/files/raw/main/ngrok/ngrok-v3-stable-linux-arm64.tgz --progress-bar
echo 
echo -e "${Yellow}[${White}+${Yellow}] Dwnloading cloudflared...${clear}"
curl -L -o $HOME/cloudflared https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-linux-arm64 --progress-bar
echo 
echo -e "${Yellow}[${White}+${Yellow}] Dwnloading loclx...${clear}"
curl -L -o $HOME/.linksnow/loclx.zip  https://api.localxpose.io/api/v2/downloads/loclx-linux-arm64.zip --progress-bar
fi

if [ "$arch" == 'arm' ];
then
echo -e "${Yellow}[${White}+${Yellow}] Dwnloading ngrok...${clear}"
curl -L -o $HOME/.linksnow/ngrok.tgz https://github.com/KasRoudra/files/raw/main/ngrok/ngrok-v3-stable-linux-arm.tgz --progress-bar
echo 
echo -e "${Yellow}[${White}+${Yellow}] Dwnloading cloudflared...${clear}"
curl -L -o $HOME/cloudflared https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-linux-arm --progress-bar
echo 
echo -e "${Yellow}[${White}+${Yellow}] Dwnloading loclx...${clear}"
curl -L -o $HOME/.linksnow/loclx.zip https://api.localxpose.io/api/v2/downloads/loclx-linux-arm.zip --progress-bar
fi
#---------------------------------------------------------------------------x84_64 starts
if [ "$arch" == 'x86_64' ];
then
echo -e "${Yellow}[${White}+${Yellow}] Dwnloading ngrok...${clear}"
#curl -L -o $HOME/.linksnow//ngrok.tgz https://github.com/KasRoudra/files/raw/main/ngrok/ngrok-v3-stable-linux-amd64.tgz --progress-bar
rm $HOME/.linksnow/ngrok.tgz > /dev/null 2>&1
ngrokc=$($HOME/.linksnow/ngrok|grep -o "DESCRIPTION")
#error checking 
	if [ "$ngrokc" == 'DESCRIPTION' ];
	then
	echo -e "${Yellow}[${White}+${Yellow}] Ngrok is working...${clear}"
	else
	echo -e "${Yellow}[${White}+${Yellow}]${Red} Ngrok won't work. Contact admin${clear}"
	#can use
	#https://github.com/KasRoudra/files/raw/main/ngrok/ngrok-v3-stable-linux-386.tgz
	#https://github.com/KasRoudra/files/raw/main/ngrok/ngrok-v3-stable-darwin-amd64.zip
	fi
	
echo -e "${Yellow}[${White}+${Yellow}] Dwnloading cloudflared...${clear}"
#curl -L -o $HOME/cloudflared https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-linux-amd64 --progress-bar
chmod +x $HOME/cloudflared
ngrokc=$($HOME/cloudflared|grep -o "DESCRIPTION")
#error checking 
	if [ "$ngrokc" == 'DESCRIPTION' ];
	then
	echo -e "${Yellow}[${White}+${Yellow}] Ngrok is working...${clear}"
	else
	echo -e "${Yellow}[${White}+${Yellow}] Ngrok won't work. Contact admin${clear}"
	#can use
	#https://github.com/KasRoudra/files/raw/main/ngrok/ngrok-v3-stable-linux-386.tgz
	#https://github.com/KasRoudra/files/raw/main/ngrok/ngrok-v3-stable-darwin-amd64.zip
	fi

echo -e "${Yellow}[${White}+${Yellow}] Dwnloading loclx...${clear}"
#curl -L -o $HOME/.linksnow/loclx.zip  https://api.localxpose.io/api/v2/downloads/loclx-linux-amd64.zip --progress-bar
fi
#---------------------------------------------------------------------------x84_64 ends
if [ "$arch" == 'x86_64' ];
then 
echo "x86_64 Architecture" 
fi

if [ "$arch" == 'arm64' ];
then 
echo "arm64 Architecture" 
fi
