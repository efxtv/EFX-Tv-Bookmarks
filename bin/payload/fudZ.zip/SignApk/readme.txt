java -jar signapk.jar certificate.pem key.pk8 your-app.apk your-app-signed.apk
zipalign -v 4 your-app-signed.apk singed_apk-final.apk




























read
openssl x509 -in certificate.pem -text




























tool -genkey -V -keystore $PWD/key.keystore -alias test -keyalg RSA -keysize 2048 -validity 1000
jarsigner -verbose -sigalg SHA1withRSA -digestalg ShA1 -keystore $PWD/key.keystore input.apk test
