# Depends - [ pkg install qemu-utils qemu-common qemu-system-x86_64-headless ]

# Download ISO https://dl-cdn.alpinelinux.org/alpine/v3.12/releases/x86_64/alpine-virt-3.12.3-x86_64.iso

# Create hdd 20GB
# qemu-img create -f qcow2 /data/data/com.termux/files/home/alpine/alpine.qcow2 20G

# $1 HDD file
# $2 ISO file
# ./install_qcow2.sh hdd.qcow2 alpine.iso

qemu-system-x86_64 -machine q35 -m 1024 -smp cpus=2 -cpu qemu64 \
-drive if=pflash,format=raw,read-only=on,file=$PREFIX/share/qemu/edk2-x86_64-code.fd \
-netdev user,id=n1,hostfwd=tcp::2222-:22 -device virtio-net,netdev=n1 \
-drive file=/data/data/com.termux/files/home/alpine/$1,format=qcow2 \
-cdrom $2 -boot d -nographic
