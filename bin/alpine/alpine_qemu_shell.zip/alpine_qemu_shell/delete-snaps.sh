# $1 sill be name of your snapshot

# List all snapshot
# qemu-img snapshot -l /path/to/your/disk_image.qcow2

# It may lookl ike this
# Snapshot list:
# ID        TAG               VM SIZE                DATE     VM CLOCK     ICOUNT
# 1         /data/data/com.termux/files/home/alpine/saved1  320 MiB 2025-01-11 20:29:04 00:04:02.051           
# 2         vm2               317 MiB 2025-01-11 21:03:30 00:05:26.354           
# 3         internet          318 MiB 2025-01-11 21:21:41 00:05:03.247           
# 4         ping              318 MiB 2025-01-11 21:24:42 00:06:23.298

# Example delete
# ./delete-snaps.sh ping
qemu-img snapshot -d $1 /data/data/com.termux/files/home/alpine/alpine.qcow2


# Start VM by typing docker
# check for list of snapshots

# Switch between snapshot
# nc -U $PREFIX/tmp/qemu-monitor-socket
# savevm newnameSnapshot
# loadvm newnameSnapshot
