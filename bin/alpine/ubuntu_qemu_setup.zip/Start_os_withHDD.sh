# Memory -m = 4048
# CPU cpus = 2 cores
# Snapshot = off (off means on)
# $1 = RM in MB 4048
# $2 = hdd path disk.qcow2
# ./file.sh 5000 /path/disk.qcow2

qemu-system-x86_64 -boot c -m $1 -enable-kvm -smp cpus=2 \
-drive file=$2,format=qcow2,if=virtio,snapshot=off \
-device virtio-net,netdev=net0 -netdev user,id=net0 \
-monitor unix:/tmp/qemu-monitor-socket,server,nowait

# OS without Snapshot commands are:
# emu-system-x86_64 -boot c -m 4048 -enable-kvm -smp cpus=2 \
# -drive file=~/qemu/fedora_disk.qcow2,format=qcow2,if=virtio \
# -device virtio-net,netdev=net0 -netdev user,id=net0 \

