# Full screen terminal output may be null
# Use command to connect to GUI
# sudo dnf install virt-viewer
# sudo dnf install remote-viewer
# remote-viewer spice://localhost:5900
# $1 = disk.qcow2
# ./file.sh disk.qcow2

 
qemu-system-x86_64 -boot c -m 4048 -enable-kvm -smp cpus=2 \
-drive file=$1,format=qcow2,if=virtio,snapshot=off \
-device virtio-net,netdev=net0 -netdev user,id=net0 \
-monitor unix:/tmp/qemu-monitor-socket,server,nowait \
-spice port=5900,disable-ticketing=on -device virtio-vga

