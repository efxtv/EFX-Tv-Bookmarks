# How to use?
# ($ savevm snapshot_name) Use command to save Snapshot
# ($ loadvm snapshot_name) To load Snapshot
# ($ info snapshots) To list all Snapshots
# ($ delvm snapshot_name)

nc -U /tmp/qemu-monitor-socket
