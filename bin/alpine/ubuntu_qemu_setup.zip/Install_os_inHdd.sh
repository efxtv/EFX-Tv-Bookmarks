# ISO = OS.iso
# DISK = fedora_disk.qcow2
# $1 ISO path
# $2 hdd path
# ./file.sh path/path/path/file.iso path/path/hdd.qcow2


qemu-system-x86_64 \
    -boot d \
    -cdrom $1 \
    -m 5048 \
    -enable-kvm \
    -drive file=$2



