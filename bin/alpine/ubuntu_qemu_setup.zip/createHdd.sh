# file size 30G
# Disk name ~/qemu/fedora_disk.qcow2
# bash file.sh 30G/100G
qemu-img create -f qcow2 ~/qemu/fedora_disk.qcow2 $1
